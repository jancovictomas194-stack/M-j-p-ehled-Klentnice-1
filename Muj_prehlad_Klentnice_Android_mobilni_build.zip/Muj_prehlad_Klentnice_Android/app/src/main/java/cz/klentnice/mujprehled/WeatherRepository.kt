package cz.klentnice.mujprehled

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

data class WeatherData(
    val temp: Double? = null, val humidity: Int? = null, val wind: Double? = null,
    val pressure: Double? = null, val description: String = "Načítám…", val updated: String = ""
)

object WeatherRepository {
    private const val LAT = 48.85
    private const val LON = 16.62

    suspend fun publicWeather(): WeatherData = withContext(Dispatchers.IO) {
        val endpoint = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON" +
            "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,pressure_msl,weather_code&timezone=Europe%2FPrague"
        val c = JSONObject(URL(endpoint).readText()).getJSONObject("current")
        WeatherData(
            temp = c.optDouble("temperature_2m").takeUnless { it.isNaN() },
            humidity = c.optInt("relative_humidity_2m"),
            wind = c.optDouble("wind_speed_10m").takeUnless { it.isNaN() }?.div(3.6),
            pressure = c.optDouble("pressure_msl").takeUnless { it.isNaN() },
            description = when (c.optInt("weather_code")) {
                0 -> "Jasno"; 1, 2 -> "Polojasno"; 3 -> "Zataženo"
                45, 48 -> "Mlha"; 51, 53, 55, 61, 63, 65, 80, 81, 82 -> "Déšť"
                71, 73, 75, 77, 85, 86 -> "Sněžení"; 95, 96, 99 -> "Bouřka"
                else -> "Proměnlivo"
            },
            updated = c.optString("time")
        )
    }

    suspend fun stationWeather(context: Context): WeatherData? = withContext(Dispatchers.IO) {
        val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val id = p.getString("station_id", "IMIKUL10") ?: "IMIKUL10"
        val key = p.getString("wu_key", "").orEmpty()
        if (key.isBlank()) return@withContext null
        val url = "https://api.weather.com/v2/pws/observations/current?stationId=$id&format=json&units=m&apiKey=$key&numericPrecision=decimal"
        val obs = JSONObject(URL(url).readText()).optJSONArray("observations")?.optJSONObject(0)
            ?: return@withContext null
        val m = obs.optJSONObject("metric") ?: return@withContext null
        WeatherData(
            temp = m.optDouble("temp", Double.NaN).takeUnless { it.isNaN() },
            humidity = obs.optInt("humidity"),
            wind = m.optDouble("windSpeed", Double.NaN).takeUnless { it.isNaN() }?.div(3.6),
            pressure = m.optDouble("pressure", Double.NaN).takeUnless { it.isNaN() },
            description = "Vlastní stanice"
        )
    }
}
