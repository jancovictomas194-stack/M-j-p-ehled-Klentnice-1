package cz.klentnice.mujprehled

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val navy = Color(0xFF082E5C)
private val white = Color.White

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleWidgetUpdates(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF0878E8))) { AppScreen() } }
    }
}

@Composable
fun AppScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("Přehled") }
    var weather by remember { mutableStateOf(WeatherData()) }
    var station by remember { mutableStateOf<WeatherData?>(null) }
    var news by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var unread by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val prefs = remember { context.getSharedPreferences("settings", 0) }
    var stationId by remember { mutableStateOf(prefs.getString("station_id", "IMIKUL10") ?: "IMIKUL10") }
    var apiKey by remember { mutableStateOf(prefs.getString("wu_key", "").orEmpty()) }

    fun refresh() {
        scope.launch {
            loading = true
            try {
                weather = WeatherRepository.publicWeather()
                station = try { WeatherRepository.stationWeather(context) } catch (_: Exception) { null }
                news = try { NewsRepository.load() } catch (_: Exception) { emptyList() }
                unread = NewsRepository.unread(context, news)
                KlentniceWidgetProvider.updateAll(context, weather, unread)
                status = if (news.isEmpty()) "Počasí aktualizováno; aktuality nejsou dostupné." else ""
            } catch (_: Exception) { status = "Nepodařilo se načíst data. Zkontroluj internet." }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1676C5), navy)))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WbSunny, null, tint = Color.Yellow, modifier = Modifier.size(38.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Můj přehled – Klentnice", color = white, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Pálava · jižní Morava", color = white.copy(.8f), fontSize = 12.sp)
                }
                IconButton(onClick = { refresh() }) { Icon(Icons.Default.Refresh, "Obnovit", tint = white) }
            }
            Spacer(Modifier.height(12.dp))
            if (page == "Přehled") {
                Card(Modifier.fillMaxWidth().height(150.dp), shape = RoundedCornerShape(20.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.klentnice_reference),
                        contentDescription = "Původní fotografie Klentnice a Pálavy",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
            if (page == "Přehled" || page == "Počasí") {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xD9082E5C)),
                    shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("KLENTNICE · VEŘEJNÉ POČASÍ", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(weather.temp?.let { "%.1f °C".format(it) } ?: "-- °C",
                                    color = white, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                                Text(weather.description, color = white, fontSize = 19.sp)
                            }
                            Icon(Icons.Default.CloudQueue, null, tint = white, modifier = Modifier.size(60.dp))
                        }
                        HorizontalDivider(color = white.copy(.35f), modifier = Modifier.padding(vertical = 12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Metric("Vlhkost", weather.humidity?.let { "$it %" } ?: "--")
                            Metric("Vítr", weather.wind?.let { "%.1f m/s".format(it) } ?: "--")
                            Metric("Tlak", weather.pressure?.let { "%.0f hPa".format(it) } ?: "--")
                        }
                        Text("Veřejná data · Open-Meteo", color = Color.LightGray, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xCC172F4B)),
                    shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(15.dp)) {
                        Text("METEOSTANICE $stationId", color = white, fontWeight = FontWeight.Bold)
                        if (station == null) {
                            Text("Pro živé měření zadej API klíč Weather Underground v Nastavení.",
                                color = Color(0xFFFFD27A), modifier = Modifier.padding(top = 6.dp))
                        } else {
                            Text("Teplota ${station?.temp?.let { "%.1f °C".format(it) } ?: "--"} · Vlhkost ${station?.humidity ?: "--"} %",
                                color = white)
                            Text("Vítr ${station?.wind?.let { "%.1f m/s".format(it) } ?: "--"} · Tlak ${station?.pressure?.let { "%.0f hPa".format(it) } ?: "--"}",
                                color = white)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("Aktuality", Color(0xFF0878E8), Icons.Default.Article, unread, Modifier.weight(1f)) {
                        page = "Aktuality"; NewsRepository.markRead(context); unread = 0
                        KlentniceWidgetProvider.updateAll(context, newsCount = 0)
                    }
                    Tile("Rádia", Color(0xFF852BC1), Icons.Default.Radio, 0, Modifier.weight(1f)) { page = "Rádia" }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("Počasí", Color(0xFF15943C), Icons.Default.Cloud, 0, Modifier.weight(1f)) { page = "Počasí" }
                    Tile("Klentnice", Color(0xFF244D70), Icons.Default.Place, 0, Modifier.weight(1f)) { page = "Klentnice" }
                }
                OutlinedButton(onClick = { page = "Nastavení" }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Icon(Icons.Default.Settings, null); Spacer(Modifier.width(8.dp)); Text("Nastavení stanice")
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { page = "Přehled" }) { Icon(Icons.Default.ArrowBack, "Zpět", tint = white) }
                    Text(page, color = white, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                when (page) {
                    "Aktuality" -> {
                        Text("Oficiální aktuality obce Klentnice", color = white)
                        TextButton(onClick = { open(context, NEWS_URL) }) { Text("Otevřít celý web obce") }
                        if (news.isEmpty()) Text("Aktuality nejsou dostupné. Obnov přehled.", color = white)
                        news.forEach { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { open(context, item.url) },
                                colors = CardDefaults.cardColors(containerColor = Color(0xDD102F52))) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(item.title, color = white, fontWeight = FontWeight.Bold)
                                    if (item.date.isNotBlank()) Text(item.date, color = Color.LightGray, fontSize = 12.sp)
                                    Text(item.summary, color = white.copy(.8f), fontSize = 12.sp, maxLines = 3)
                                }
                            }
                        }
                    }
                    "Rádia" -> {
                        Text("Vyber stanici. Otevře se oficiální web rádia.", color = white)
                        LinkRow("Rádio Jih", "https://www.radiojih.cz/")
                        LinkRow("Evropa 2", "https://www.evropa2.cz/")
                        LinkRow("Kiss", "https://www.kiss.cz/")
                        LinkRow("Rádio Impuls", "https://www.impuls.cz/")
                    }
                    "Klentnice" -> {
                        LinkRow("Web obce Klentnice", "https://www.klentnice.cz/")
                        LinkRow("Aktuality obce", NEWS_URL)
                        LinkRow("Kalendář akcí", "https://www.klentnice.cz/aktualne/kalendar-akci/")
                    }
                    "Nastavení" -> {
                        Text("Připojení vlastní meteostanice", color = white)
                        OutlinedTextField(value = stationId, onValueChange = { stationId = it },
                            label = { Text("ID stanice") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it },
                            label = { Text("Weather Underground API klíč") }, singleLine = true,
                            modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            prefs.edit().putString("station_id", stationId.trim())
                                .putString("wu_key", apiKey.trim()).apply()
                            refresh(); page = "Přehled"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Uložit a ověřit stanici") }
                        Text("Veřejné počasí funguje i bez klíče. Pro vlastní měření je nutný platný API přístup a správné Station ID.",
                            color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
            if (status.isNotBlank()) Text(status, color = Color(0xFFFFD27A), modifier = Modifier.padding(8.dp))
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            Text("Údaje se aktualizují podle dostupnosti internetu.", color = white.copy(.65f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color.LightGray, fontSize = 11.sp)
        Text(value, color = white, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun Tile(label: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector,
                 count: Int, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(104.dp), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = color)) {
        Box(Modifier.fillMaxSize().padding(10.dp)) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = white, modifier = Modifier.size(34.dp))
                Text(label, color = white, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            if (count > 0) Box(Modifier.align(Alignment.TopEnd).background(Color.Red, RoundedCornerShape(50)).padding(horizontal = 7.dp, vertical = 3.dp)) {
                Text(count.toString(), color = white, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun LinkRow(title: String, url: String) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { open(context, url) },
        colors = CardDefaults.cardColors(containerColor = Color(0xDD12385E))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.OpenInNew, null, tint = white)
            Spacer(Modifier.width(12.dp))
            Text(title, color = white, fontWeight = FontWeight.Bold)
        }
    }
}

private fun open(context: android.content.Context, url: String) {
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
