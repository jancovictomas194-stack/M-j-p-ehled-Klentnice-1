package cz.klentnice.mujprehled

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class KlentniceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context)
        scheduleWidgetUpdates(context)
    }

    companion object {
        fun updateAll(context: Context, weather: WeatherData? = null, newsCount: Int? = null) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, KlentniceWidgetProvider::class.java))
            val p = context.getSharedPreferences("widget_data", Context.MODE_PRIVATE)
            val w = weather
            if (w != null) {
                p.edit()
                    .putString("temp", w.temp?.let { "%.1f °C".format(it) } ?: "-- °C")
                    .putString("condition", w.description)
                    .putString("humidity", w.humidity?.let { "$it %" } ?: "-- %")
                    .putString("wind", w.wind?.let { "%.1f m/s".format(it) } ?: "-- m/s")
                    .putString("pressure", w.pressure?.let { "%.0f hPa".format(it) } ?: "-- hPa")
                    .apply()
            }
            if (newsCount != null) p.edit().putInt("news_count", newsCount).apply()
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_klentnice)
                views.setTextViewText(R.id.widget_temp, p.getString("temp", "-- °C"))
                views.setTextViewText(R.id.widget_condition, p.getString("condition", "Počasí v Klentnici"))
                views.setTextViewText(R.id.widget_details,
                    "Vlhkost ${p.getString("humidity", "-- %")}   Vítr ${p.getString("wind", "-- m/s")}   Tlak ${p.getString("pressure", "-- hPa")}")
                val count = p.getInt("news_count", 0)
                views.setTextViewText(R.id.widget_news, if (count > 0) "● $count" else "")
                val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                intent?.let {
                    val pending = android.app.PendingIntent.getActivity(context, 0, it,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
                    views.setOnClickPendingIntent(R.id.widget_root, pending)
                }
                manager.updateAppWidget(id, views)
            }
        }
    }
}

class WeatherWidgetWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val weather = WeatherRepository.publicWeather()
        withContext(Dispatchers.Main) { KlentniceWidgetProvider.updateAll(applicationContext, weather) }
        Result.success()
    } catch (_: Exception) { Result.retry() }
}

fun scheduleWidgetUpdates(context: Context) {
    val request = PeriodicWorkRequestBuilder<WeatherWidgetWorker>(30, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "klentnice_widget_refresh", ExistingPeriodicWorkPolicy.UPDATE, request)
}
