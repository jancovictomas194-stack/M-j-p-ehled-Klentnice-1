package cz.klentnice.mujprehled

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

const val NEWS_URL = "https://www.klentnice.cz/aktualne/aktuality/"

data class NewsItem(val title: String, val date: String, val url: String, val summary: String)

object NewsRepository {
    suspend fun load(): List<NewsItem> = withContext(Dispatchers.IO) {
        val doc = Jsoup.connect(NEWS_URL).userAgent("Mozilla/5.0").timeout(15000).get()
        val found = LinkedHashMap<String, NewsItem>()
        doc.select("a[href]").forEach { a ->
            val title = a.text().trim()
            val href = a.absUrl("href")
            val parent = a.parent()?.parent()?.text().orEmpty()
            val date = Regex("""\d{1,2}\.\s*\d{1,2}\.\s*20\d{2}""").find(parent)?.value.orEmpty()
            if (title.length > 8 && href.startsWith("https://www.klentnice.cz/") &&
                !href.contains("/aktualne/aktuality/") && !title.equals("Detail", true)) {
                found.putIfAbsent(href, NewsItem(title, date, href, parent.take(220)))
            }
        }
        found.values.take(30)
    }

    fun markRead(context: Context) {
        context.getSharedPreferences("news", Context.MODE_PRIVATE).edit()
            .putLong("last_read", System.currentTimeMillis()).apply()
    }

    fun unread(context: Context, list: List<NewsItem>): Int {
        val last = context.getSharedPreferences("news", Context.MODE_PRIVATE).getLong("last_read", 0L)
        if (last == 0L) return list.size
        return list.count { item ->
            try {
                val parts = Regex("""(\d{1,2})\.\s*(\d{1,2})\.\s*(20\d{2})""").find(item.date)!!.groupValues
                val cal = java.util.Calendar.getInstance().apply {
                    set(parts[3].toInt(), parts[2].toInt() - 1, parts[1].toInt(), 12, 0, 0)
                }
                cal.timeInMillis > last
            } catch (_: Exception) { false }
        }
    }
}
