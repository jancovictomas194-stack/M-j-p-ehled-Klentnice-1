# Můj přehled – Klentnice (Android)

Zdrojový projekt Android aplikace v Kotlinu a Jetpack Compose. Obsahuje také klasický Android App Widget (RemoteViews), který lze přidat na domovskou obrazovku.

## Funkce
- Hlavní obrazovka v tmavě modrém stylu podle dodaného návrhu.
- Veřejné počasí pro Klentnici přes Open-Meteo.
- Připravené připojení k vlastní stanici Weather Underground PWS; výchozí Station ID `IMIKUL10`.
- Nastavení API klíče a ID stanice v aplikaci.
- Aktuality z oficiálního webu obce Klentnice.
- Červené počítadlo nových aktualit (datumový odhad z webové stránky).
- Odkazy pouze na Rádio Jih, Evropu 2, Kiss a Rádio Impuls.
- Původní dodaný obrázek Klentnice/Pálavy je vložen do horní části hlavní obrazovky.
- Domovský widget s teplotou, stavem počasí, vlhkostí, větrem, tlakem a počtem nových aktualit.
- Widget obnovuje veřejné počasí přibližně každých 30 minut přes WorkManager.

## Omezení a co je nutné ověřit
1. Souřadnice veřejného počasí jsou přibližné pro Klentnici: 48.85, 16.62.
2. Pro vlastní stanici je nutný platný Weather Underground API klíč a potvrzené ID stanice. API klíč se zadává v Nastavení.
3. Parser aktualit pracuje s veřejným HTML webem obce; pokud obec změní strukturu stránky, bude nutné parser upravit. Počítadlo je orientační.
4. Rádia jsou odkazy na oficiální stránky, nikoli integrovaný přímý streamový přehrávač.
5. Widget zobrazuje veřejné počasí; vlastní stanice je zobrazena v hlavní aplikaci po nastavení přístupu.
6. Dodaný původní obrázek je vložen jako fotografický banner v horní části přehledu; protože jde o snímek celé obrazovky, banner zobrazuje výřez tohoto obrázku.

## Sestavení APK
Vyžaduje Android Studio a Android SDK:
1. Rozbal ZIP.
2. Android Studio → Open → vyber složku `Muj_prehlad_Klentnice_Android`.
3. Počkej na Gradle Sync.
4. Spusť na emulátoru nebo telefonu.
5. Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK bude v `app/build/outputs/apk/debug/app-debug.apk`.

Minimální Android: 8.0 (API 26).

## Přidání widgetu
Na ploše telefonu podrž prst na prázdném místě → Widgety → Můj přehled – Klentnice → přetáhni widget na plochu. Přesné názvy se mohou lišit podle launcheru.

## Použité zdroje
- Obec Klentnice: https://www.klentnice.cz/
- Aktuality: https://www.klentnice.cz/aktualne/aktuality/
- Open-Meteo: https://open-meteo.com/en/docs
- Android App Widgets: https://developer.android.com/develop/ui/views/appwidgets


## Sestavení APK pouze z mobilu přes GitHub Actions
1. Na mobilu otevři https://github.com/ a vytvoř bezplatný účet nebo se přihlas.
2. Vytvoř nový repository s názvem `Muj-prehled-Klentnice`.
3. Nahraj obsah celé složky projektu, včetně skryté složky `.github/workflows`.
4. Otevři záložku Actions a spusť workflow `Build Android APK`.
5. Po dokončení otevři běh workflow a v části Artifacts stáhni `Muj-prehled-Klentnice-APK`.
6. Rozbal stažený artifact ZIP a otevři `app-debug.apk`. Povol instalaci z daného zdroje, pokud se Android zeptá.

GitHub Actions vyžaduje účet. Výsledný debug APK je instalační testovací balíček, nikoli vydání publikované v Google Play.
